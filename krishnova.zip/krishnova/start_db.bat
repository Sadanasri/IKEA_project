@echo off
echo Starting PostgreSQL database via Docker...
docker-compose up -d
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Docker command failed. Please ensure Docker Desktop is installed and running!
) else (
    echo [SUCCESS] PostgreSQL is starting in the background.
)
pause
