package com.krishnova.orderprocessing;

import com.krishnova.orderprocessing.model.Order;
import com.krishnova.orderprocessing.model.OrderItem;
import com.krishnova.orderprocessing.model.Product;
import com.krishnova.orderprocessing.repository.OrderRepository;
import com.krishnova.orderprocessing.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;

    @Override
    public void run(String... args) {
        // Seed Products
        if (productRepository.count() == 0) {
            productRepository.saveAll(List.of(
                    Product.builder().name("HEMNES Bed frame").price(15000.0).stockQuantity(10)
                            .description("Classic bed frame").build(),
                    Product.builder().name("BILLY Bookcase").price(3500.0).stockQuantity(25)
                            .description("Versatile shelving unit").build(),
                    Product.builder().name("KALLAX Shelf unit").price(4500.0).stockQuantity(15)
                            .description("Square shelving").build(),
                    Product.builder().name("MALM Chest of drawers").price(8000.0).stockQuantity(12)
                            .description("Sleek storage").build()));
        }

        // Seed Initial Order
        if (orderRepository.count() == 0) {
            Order order = Order.builder()
                    .customerName("Jane Smith")
                    .totalAmount(22000.0)
                    .build();

            OrderItem item1 = OrderItem.builder().productName("HEMNES Bed frame").quantity(1).price(15000.0)
                    .order(order).build();
            OrderItem item2 = OrderItem.builder().productName("BILLY Bookcase").quantity(2).price(3500.0).order(order)
                    .build();

            order.setItems(List.of(item1, item2));
            orderRepository.save(order);
        }
    }
}
