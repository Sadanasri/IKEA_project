package com.krishnova.orderprocessing.dto;

import com.krishnova.orderprocessing.model.Order;
import com.krishnova.orderprocessing.model.OrderItem;
import com.krishnova.orderprocessing.model.OrderStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderDTO {
        private Long id;
        private String customerName;
        private Double totalAmount;
        private OrderStatus status;
        private LocalDateTime orderDate;
        private List<OrderItemDTO> items;

        public Order toEntity() {
                Order order = Order.builder()
                                .id(this.id)
                                .customerName(this.customerName)
                                .totalAmount(this.totalAmount)
                                .status(this.status)
                                .orderDate(this.orderDate)
                                .build();

                if (this.items != null) {
                        order.setItems(this.items.stream()
                                        .map(item -> OrderItem.builder()
                                                        .productName(item.getProductName())
                                                        .quantity(item.getQuantity())
                                                        .price(item.getPrice())
                                                        .order(order)
                                                        .build())
                                        .collect(java.util.stream.Collectors.toList()));
                }
                return order;
        }

        public static OrderDTO fromEntity(Order order) {
                return OrderDTO.builder()
                                .id(order.getId())
                                .customerName(order.getCustomerName())
                                .totalAmount(order.getTotalAmount())
                                .status(order.getStatus())
                                .orderDate(order.getOrderDate())
                                .items(order.getItems().stream()
                                                .map(item -> OrderItemDTO.builder()
                                                                .productName(item.getProductName())
                                                                .quantity(item.getQuantity())
                                                                .price(item.getPrice())
                                                                .build())
                                                .collect(java.util.stream.Collectors.toList()))
                                .build();
        }

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class OrderItemDTO {
                private String productName;
                private Integer quantity;
                private Double price;
        }
}
