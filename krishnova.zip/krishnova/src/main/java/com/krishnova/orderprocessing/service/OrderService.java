package com.krishnova.orderprocessing.service;

import com.krishnova.orderprocessing.dto.OrderDTO;
import com.krishnova.orderprocessing.model.Order;
import com.krishnova.orderprocessing.model.OrderStatus;
import com.krishnova.orderprocessing.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;

    @Transactional
    public OrderDTO createOrder(OrderDTO orderDTO) {
        Order order = orderDTO.toEntity();

        // Calculate total amount if not provided
        if (order.getTotalAmount() == null) {
            double total = order.getItems().stream()
                    .mapToDouble(item -> item.getPrice() * item.getQuantity())
                    .sum();
            order.setTotalAmount(total);
        }

        return OrderDTO.fromEntity(orderRepository.save(order));
    }

    public List<OrderDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(OrderDTO::fromEntity)
                .collect(Collectors.toList());
    }

    public OrderDTO getOrderById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
        return OrderDTO.fromEntity(order);
    }

    @Transactional
    public OrderDTO updateOrderStatus(Long id, OrderStatus status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
        order.setStatus(status);
        return OrderDTO.fromEntity(orderRepository.save(order));
    }
}
